import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart'; // Wajib buat Firebase
import 'package:firebase_auth/firebase_auth.dart'; // Wajib buat cek status login
import 'package:google_fonts/google_fonts.dart'; // Biar fontnya modern

// Import layar-layar kita
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';

void main() async {
  // 1. Pastikan binding Flutter siap sebelum jalanin kode async
  WidgetsFlutterBinding.ensureInitialized();
  
  // 2. Inisialisasi Firebase (Konek ke Server Google)
  await Firebase.initializeApp();
  
  // 3. Jalanin Aplikasi
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Ilangin pita debug di pojok
      title: 'Portal Berita Firebase',
      
      // --- TEMA APLIKASI ---
      theme: ThemeData(
        // Warna Utama: Biru Elegan (Sama kayak Login Screen)
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0D47A1), 
          primary: const Color(0xFF0D47A1),
          secondary: const Color(0xFF42A5F5),
        ),
        useMaterial3: true,
        
        // Setup Font Global jadi Poppins (Biar Rapi & Modern)
        textTheme: GoogleFonts.poppinsTextTheme(
          Theme.of(context).textTheme,
        ),
        
        // Style AppBar Default
        appBarTheme: AppBarTheme(
          elevation: 0,
          centerTitle: true,
          backgroundColor: Colors.white,
          foregroundColor: Colors.black87,
          titleTextStyle: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
      ),

      // --- LOGIKA SATPAM OTOMATIS (AUTH GATE) ---
      // StreamBuilder ini bakal mantau terus status login user secara Realtime
      home: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          // 1. Kalau lagi loading status koneksi...
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }

          // 2. Kalau ada datanya (User SUDAH LOGIN)
          if (snapshot.hasData) {
            return const HomeScreen(); // Langsung masuk Home
          }

          // 3. Kalau datanya null (User BELUM LOGIN / LOGOUT)
          return const LoginScreen(); // Suruh Login dulu
        },
      ),
    );
  }
}