import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/firestore_service.dart';
import 'detail_news_screen.dart';

class CategoryNewsScreen extends StatelessWidget {
  final String category;

  const CategoryNewsScreen({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    final firestoreService = FirestoreService();

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Text(
          "$category NEWS",
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, letterSpacing: 1.5, fontStyle: FontStyle.italic),
        ),
        backgroundColor: const Color(0xFFB71C1C), // Merah Racing
        foregroundColor: Colors.white,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: firestoreService.getNewsStream(category: category),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text("Belum ada berita $category.", style: GoogleFonts.poppins()));
          }

          var newsList = snapshot.data!.docs;

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: newsList.length,
            itemBuilder: (context, index) {
              var data = newsList[index].data() as Map<String, dynamic>;
              return Card(
                elevation: 4,
                margin: const EdgeInsets.only(bottom: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(10),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      data['image'] ?? '',
                      width: 100,
                      height: 80,
                      fit: BoxFit.cover,
                      errorBuilder: (c,e,s) => Container(width: 100, color: Colors.grey, child: const Icon(Icons.broken_image)),
                    ),
                  ),
                  title: Text(data['title'], maxLines: 2, overflow: TextOverflow.ellipsis, style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
                  subtitle: Text(data['author'], style: GoogleFonts.poppins(color: Colors.grey)),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (c) => DetailNewsScreen(data: data, docId: newsList[index].id))),
                ),
              );
            },
          );
        },
      ),
    );
  }
}