import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import 'profile_screen.dart';
import 'detail_news_screen.dart';
import 'category_news_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestoreService = FirestoreService();
    final user = FirebaseAuth.instance.currentUser;
    
    // Generate data Motorsport (sekali aja pas pertama kali buka)
    firestoreService.addDummyNews(); 

    return Scaffold(
      backgroundColor: Colors.white,
      // --- APP BAR CUSTOM ---
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Row(
          children: [
            Text("RACE", style: GoogleFonts.poppins(fontWeight: FontWeight.w900, fontSize: 24, color: Colors.black, fontStyle: FontStyle.italic)),
            Text("WORLD", style: GoogleFonts.poppins(fontWeight: FontWeight.w900, fontSize: 24, color: const Color(0xFFB71C1C), fontStyle: FontStyle.italic)),
          ],
        ),
        actions: [
          IconButton(
            icon: const CircleAvatar(backgroundColor: Colors.black, child: Icon(Icons.person, color: Colors.white)),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (c) => const ProfileScreen())),
          ),
          const SizedBox(width: 10),
        ],
      ),
      
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. GREETING KECIL
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text("Welcome back, ${user?.displayName?.split(' ')[0] ?? 'Racer'}!", style: GoogleFonts.poppins(color: Colors.grey)),
            ),
            const SizedBox(height: 10),

            // 2. KATEGORI (CHIPS)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: ['F1', 'MotoGP', 'GT3', 'WRC', 'Nascar'].map((category) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: ActionChip(
                      label: Text(category),
                      labelStyle: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white),
                      backgroundColor: Colors.black,
                      shape: const StadiumBorder(),
                      onPressed: () {
                        // BUKA HALAMAN KATEGORI SENDIRI
                        Navigator.push(context, MaterialPageRoute(builder: (c) => CategoryNewsScreen(category: category)));
                      },
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 20),

            // 3. TRENDING TOPIC (HIGHLIGHT BESAR)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text("TRENDING TOPIC 🔥", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w800, fontStyle: FontStyle.italic)),
            ),
            const SizedBox(height: 10),
            
            // Ambil 1 Berita Trending
            FutureBuilder<QuerySnapshot>(
              future: firestoreService.getTrendingNews(),
              builder: (context, snapshot) {
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) return const SizedBox(); // Kalau gak ada skip
                var data = snapshot.data!.docs[0].data() as Map<String, dynamic>;
                
                return GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (c) => DetailNewsScreen(data: data, docId: snapshot.data!.docs[0].id))),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    height: 220,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      image: DecorationImage(image: NetworkImage(data['image']), fit: BoxFit.cover),
                      boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 10, offset: const Offset(0, 5))]
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        gradient: const LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black, Colors.transparent]),
                      ),
                      padding: const EdgeInsets.all(20),
                      alignment: Alignment.bottomLeft,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: const Color(0xFFB71C1C), borderRadius: BorderRadius.circular(5)),
                            child: Text(data['category'] ?? 'News', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                          ),
                          const SizedBox(height: 8),
                          Text(data['title'], style: GoogleFonts.poppins(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold), maxLines: 2, overflow: TextOverflow.ellipsis),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 25),

            // 4. LATEST NEWS (CAMPUR)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("LATEST UPDATES", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w800, fontStyle: FontStyle.italic)),
                  // Tombol Logout Mini
                  IconButton(icon: const Icon(Icons.logout, color: Colors.grey), onPressed: () => AuthService().signOut()),
                ],
              ),
            ),
            
            StreamBuilder<QuerySnapshot>(
              stream: firestoreService.getNewsStream(category: 'All'), // Ambil semua
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
                
                var newsList = snapshot.data!.docs;
                // Skip berita pertama kalau itu trending (biar gak double) - Optional logic
                
                return ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: newsList.length,
                  itemBuilder: (context, index) {
                    var data = newsList[index].data() as Map<String, dynamic>;
                    
                    return Container(
                      margin: const EdgeInsets.only(bottom: 20),
                      child: InkWell(
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (c) => DetailNewsScreen(data: data, docId: newsList[index].id))),
                        child: Row(
                          children: [
                            // Gambar Kecil
                            ClipRRect(
                              borderRadius: BorderRadius.circular(15),
                              child: Image.network(data['image'] ?? '', width: 100, height: 100, fit: BoxFit.cover),
                            ),
                            const SizedBox(width: 15),
                            // Teks
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(data['category'] ?? 'General', style: GoogleFonts.poppins(color: const Color(0xFFB71C1C), fontSize: 12, fontWeight: FontWeight.bold)),
                                  const SizedBox(height: 5),
                                  Text(data['title'], style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 15), maxLines: 2, overflow: TextOverflow.ellipsis),
                                  const SizedBox(height: 5),
                                  Text(data['author'], style: GoogleFonts.poppins(color: Colors.grey, fontSize: 12)),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 50),
          ],
        ),
      ),
    );
  }
}