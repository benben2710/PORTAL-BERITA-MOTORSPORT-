import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class DetailNewsScreen extends StatelessWidget {
  final Map<String, dynamic> data;
  final String docId;

  const DetailNewsScreen({super.key, required this.data, required this.docId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Image.network(
                data['image'] ?? 'https://via.placeholder.com/300',
                fit: BoxFit.cover,
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data['title'] ?? '',
                    style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    "Penulis: ${data['author'] ?? '-'}",
                    style: const TextStyle(color: Colors.grey),
                  ),
                  const Divider(height: 30),
                  Text(
                    data['content'] ?? '',
                    style: GoogleFonts.poppins(fontSize: 16, height: 1.6),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}