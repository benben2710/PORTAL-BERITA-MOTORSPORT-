import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/firestore_service.dart';
import '../services/auth_service.dart'; // Butuh buat logout otomatis pas delete

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _firestoreService = FirestoreService();
  bool isEditing = false;

  // Fungsi Konfirmasi Hapus Akun
  void _confirmDeleteAccount() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Hapus Akun?"),
        content: const Text("Tindakan ini permanen. Semua data kamu bakal ilang. Yakin?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Batal")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async {
              await _firestoreService.deleteAccount(); // Panggil fungsi delete
              Navigator.pop(context); // Tutup dialog
              Navigator.pop(context); // Tutup halaman profil (Balik ke Auth Gate -> Login)
            },
            child: const Text("HAPUS SEKARANG", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Racer Profile"), centerTitle: true),
      body: StreamBuilder<DocumentSnapshot>(
        stream: _firestoreService.getUserStream(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          
          var data = snapshot.data!.data() as Map<String, dynamic>?;
          if (data == null) return const Center(child: Text("Error Data"));

          if (!isEditing && _nameController.text.isEmpty) {
            _nameController.text = data['name'] ?? '';
            _emailController.text = data['email'] ?? '';
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.black,
                  backgroundImage: NetworkImage('https://image.pollinations.ai/prompt/racer%20helmet%20avatar'), // Avatar keren
                ),
                const SizedBox(height: 20),
                
                TextField(controller: _nameController, enabled: isEditing, decoration: const InputDecoration(labelText: "Nama Racer", border: OutlineInputBorder())),
                const SizedBox(height: 15),
                TextField(controller: _emailController, enabled: false, decoration: const InputDecoration(labelText: "Email Team", border: OutlineInputBorder())),
                const SizedBox(height: 30),

                isEditing 
                ? ElevatedButton(
                    onPressed: () async {
                      await _firestoreService.updateUserProfile(_nameController.text, _emailController.text);
                      setState(() => isEditing = false);
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Profil Updated!")));
                    },
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.black, foregroundColor: Colors.white, minimumSize: const Size(double.infinity, 50)),
                    child: const Text("SIMPAN PERUBAHAN"),
                  )
                : ElevatedButton(
                    onPressed: () => setState(() => isEditing = true),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.black, foregroundColor: Colors.white, minimumSize: const Size(double.infinity, 50)),
                    child: const Text("EDIT PROFIL")
                  ),

                const SizedBox(height: 40),
                const Divider(),
                const SizedBox(height: 20),

                // TOMBOL DELETE ACCOUNT (DANGER ZONE)
                TextButton.icon(
                  onPressed: _confirmDeleteAccount,
                  icon: const Icon(Icons.delete_forever, color: Colors.red),
                  label: Text("Hapus Akun Permanen", style: GoogleFonts.poppins(color: Colors.red, fontWeight: FontWeight.bold)),
                )
              ],
            ),
          );
        },
      ),
    );
  }
}