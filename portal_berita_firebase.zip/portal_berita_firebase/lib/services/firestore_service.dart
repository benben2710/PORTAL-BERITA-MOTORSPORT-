import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // --- 1. FITUR BERITA ---

  // Ambil Stream Berita (Bisa difilter per kategori)
  Stream<QuerySnapshot> getNewsStream({String? category}) {
    if (category != null && category != 'All') {
      return _db
          .collection('news')
          .where('category', isEqualTo: category)
          .orderBy('createdAt', descending: true)
          .snapshots();
    }
    return _db.collection('news').orderBy('createdAt', descending: true).snapshots();
  }
  
  // Ambil Berita Trending (Limit 3 biar seru gesernya kalo mau dibikin carousel, tapi skrg 1 dulu)
  Future<QuerySnapshot> getTrendingNews() async {
    return _db.collection('news').where('isTrending', isEqualTo: true).limit(1).get();
  }

  // GENERATE DATA MOTORSPORT JUMBO (15 BERITA)
  Future<void> addDummyNews() async {
    var snapshot = await _db.collection('news').get();
    
    // Cuma generate kalau database kosong biar gak double
    if (snapshot.docs.isEmpty) {
      List<Map<String, dynamic>> motorsportData = [
        // --- FORMULA 1 (Highlight) ---
        {
          'title': 'BREAKING: Hamilton Pensiun Akhir Musim Ini?',
          'content': 'Rumor beredar kencang di paddock bahwa juara dunia 7 kali Lewis Hamilton sedang mempertimbangkan gantung helm...',
          'image': 'https://picsum.photos/seed/hamilton/600/400',
          'author': 'Sky Sports F1',
          'category': 'F1',
          'isTrending': true, // TRENDING TOPIC
          'createdAt': FieldValue.serverTimestamp(),
        },
        {
          'title': 'Verstappen Dominan di Suzuka, Red Bull Tak Terkejar',
          'content': 'Max Verstappen kembali menunjukkan kelasnya dengan memenangkan GP Jepang dengan selisih 20 detik...',
          'image': 'https://picsum.photos/seed/rb19/600/400',
          'author': 'F1 Insider',
          'category': 'F1',
          'isTrending': false,
          'createdAt': FieldValue.serverTimestamp(),
        },
        {
          'title': 'McLaren Bawa Upgrade Besar di Miami GP',
          'content': 'Lando Norris optimis paket aerodinamika baru akan membawa McLaren ke barisan depan...',
          'image': 'https://picsum.photos/seed/mclaren/600/400',
          'author': 'Autosport',
          'category': 'F1',
          'isTrending': false,
          'createdAt': FieldValue.serverTimestamp(),
        },

        // --- MOTOGP ---
        {
          'title': 'Bagnaia vs Martin: Duel Sengit Hingga Tikungan Terakhir',
          'content': 'Perebutan gelar juara dunia MotoGP semakin panas setelah Pecco Bagnaia menyalip Martin di lap terakhir...',
          'image': 'https://picsum.photos/seed/pecco/600/400',
          'author': 'MotoGP Update',
          'category': 'MotoGP',
          'isTrending': false,
          'createdAt': FieldValue.serverTimestamp(),
        },
        {
          'title': 'Pedro Acosta: Bocah Ajaib yang Bikin Senior Ketar-Ketir',
          'content': 'Debutan GasGas Tech3 ini kembali naik podium dan membuktikan dia bukan rookie biasa...',
          'image': 'https://picsum.photos/seed/acosta/600/400',
          'author': 'The Race',
          'category': 'MotoGP',
          'isTrending': false,
          'createdAt': FieldValue.serverTimestamp(),
        },
        {
          'title': 'Honda & Yamaha Masih Kesulitan Kejar Ducati',
          'content': 'Pabrikan Jepang masih belum menemukan setelan terbaik untuk menandingi dominasi motor Eropa...',
          'image': 'https://picsum.photos/seed/honda/600/400',
          'author': 'Crash Net',
          'category': 'MotoGP',
          'isTrending': false,
          'createdAt': FieldValue.serverTimestamp(),
        },

        // --- GT3 & ENDURANCE ---
        {
          'title': 'Valentino Rossi Menang Perdana di GT World Challenge!',
          'content': 'Legenda MotoGP Valentino Rossi akhirnya meraih kemenangan pertamanya di balap mobil GT3 bersama BMW...',
          'image': 'https://picsum.photos/seed/vr46gt/600/400',
          'author': 'GT World',
          'category': 'GT3',
          'isTrending': false,
          'createdAt': FieldValue.serverTimestamp(),
        },
        {
          'title': 'Ferrari 499P Siap Pertahankan Gelar Le Mans 24H',
          'content': 'Hypercar Ferrari tampil impresif di sesi latihan bebas jelang balapan ketahanan legendaris...',
          'image': 'https://picsum.photos/seed/lemans/600/400',
          'author': 'WEC News',
          'category': 'GT3',
          'isTrending': false,
          'createdAt': FieldValue.serverTimestamp(),
        },

        // --- WRC (Rally) ---
        {
          'title': 'Kalle Rovanpera Menari di Atas Salju Rally Sweden',
          'content': 'Juara dunia WRC memamerkan skill drifting luar biasa di lintasan bersalju Swedia...',
          'image': 'https://picsum.photos/seed/wrcsnow/600/400',
          'author': 'DirtFish',
          'category': 'WRC',
          'isTrending': false,
          'createdAt': FieldValue.serverTimestamp(),
        },
        {
          'title': 'Hyundai i20 N Rally1 Alami Masalah Hybrid',
          'content': 'Thierry Neuville harus mundur dari pimpinan lomba akibat kerusakan sistem hybrid...',
          'image': 'https://picsum.photos/seed/hyundai/600/400',
          'author': 'Rally One',
          'category': 'WRC',
          'isTrending': false,
          'createdAt': FieldValue.serverTimestamp(),
        },

        // --- NASCAR ---
        {
          'title': 'Finish Terketat Sejarah NASCAR di Atlanta!',
          'content': 'Tiga mobil menyentuh garis finish secara bersamaan dengan selisih 0.003 detik...',
          'image': 'https://picsum.photos/seed/nascar/600/400',
          'author': 'NASCAR Official',
          'category': 'Nascar',
          'isTrending': false,
          'createdAt': FieldValue.serverTimestamp(),
        },
      ];

      for (var data in motorsportData) {
        await _db.collection('news').add(data);
      }
    }
  }

  // --- 2. FITUR PROFILE & DELETE ACCOUNT ---

  Stream<DocumentSnapshot> getUserStream() {
    String uid = _auth.currentUser!.uid;
    return _db.collection('users').doc(uid).snapshots();
  }

  Future<void> updateUserProfile(String name, String email) async {
    String uid = _auth.currentUser!.uid;
    await _db.collection('users').doc(uid).update({'name': name, 'email': email});
    await _auth.currentUser!.updateDisplayName(name);
  }

  Future<void> deleteAccount() async {
    User? user = _auth.currentUser;
    if (user != null) {
      await _db.collection('users').doc(user.uid).delete();
      await user.delete();
    }
  }
}